import { 
  UserProfile, 
  Course, 
  SubjectAttendanceSummary, 
  Assignment, 
  Submission, 
  Exam, 
  SemesterTranscript, 
  NotificationItem, 
  MessageItem, 
  LeaveExemption, 
  TimetableSlot 
} from '../types';

export const INITIAL_STUDENT_PROFILE: UserProfile = {
  uid: 'student_elena_vance',
  email: 'elena.vance@campus.edu',
  displayName: 'Elena Vance',
  role: 'student',
  studentId: '#CS-2022-8492',
  department: 'School of Computing & AI',
  semester: 'Semester 5 - B.Tech CS',
  phone: '+1 (555) 392-8411',
  avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
  currentCgpa: 3.84,
  attendancePercentage: 86.4,
  termCredits: '22/24',
  nextClass: 'Distributed Systems @ 10:30 AM (LH-302)',
  createdAt: '2022-08-15T09:00:00Z',
};

export const DEMO_USERS: UserProfile[] = [
  INITIAL_STUDENT_PROFILE,
  {
    uid: 'faculty_alan_vance',
    email: 'alan.vance@faculty.campus.edu',
    displayName: 'Dr. Alan Vance',
    role: 'faculty',
    facultyId: 'FAC-CS-104',
    department: 'School of Computing & AI',
    semester: 'Lead Faculty - Systems',
    phone: '+1 (555) 782-9901',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    attendancePercentage: 98.2,
  },
  {
    uid: 'admin_dean_office',
    email: 'chaturwedidheeraj911@gmail.com', // runtime user email for admin privileges
    displayName: 'Academic Registrar & Dean',
    role: 'admin',
    department: 'University Academic Council',
    semester: 'Administration Hub',
    phone: '+1 (555) 100-2020',
    avatarUrl: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&auto=format&fit=crop&q=80',
  }
];

export const INITIAL_COURSES: Course[] = [
  {
    id: 'cs-501',
    code: 'CS-501',
    name: 'Distributed Systems',
    department: 'Core Computer Science',
    credits: 4.0,
    semester: 'Fall 2024 (Semester 5)',
    facultyName: 'Dr. Alan Vance',
    facultyEmail: 'alan.vance@faculty.campus.edu',
    room: 'Lecture Hall LH-302',
    totalSessions: 42,
    scheduleSummary: 'Tue & Thu 10:30 AM - 11:45 AM',
    syllabusTopics: ['RPC & Consensus Models', 'Paxos & Raft Mechanisms', 'Vector Clocks & Snapshotting', 'CAP Theorem & Fault Tolerance']
  },
  {
    id: 'cs-502',
    code: 'CS-502',
    name: 'Advanced Algorithms',
    department: 'Core Computer Science',
    credits: 4.0,
    semester: 'Fall 2024 (Semester 5)',
    facultyName: 'Dr. Sarah Jenkins',
    facultyEmail: 'sarah.jenkins@faculty.campus.edu',
    room: 'CS-204',
    totalSessions: 48,
    scheduleSummary: 'Mon & Wed 09:00 AM - 10:15 AM',
    syllabusTopics: ['Dynamic Programming Strategies', 'Network Flow Graphs', 'NP-Completeness Reductions', 'Approximation Algorithms']
  },
  {
    id: 'cs-503',
    code: 'CS-503',
    name: 'Machine Learning & AI',
    department: 'AI & Data Specialization',
    credits: 4.0,
    semester: 'Fall 2024 (Semester 5)',
    facultyName: 'Prof. Kevin Zhang',
    facultyEmail: 'kevin.zhang@faculty.campus.edu',
    room: 'Computing Lab 3',
    totalSessions: 50,
    scheduleSummary: 'Wed & Fri 01:30 PM - 03:30 PM',
    syllabusTopics: ['Convolutional Neural Nets', 'Transformer Architectures', 'Loss Landscapes & Optimization', 'Feature Engineering']
  },
  {
    id: 'cs-504',
    code: 'CS-504',
    name: 'Compiler Design',
    department: 'Systems Division',
    credits: 4.0,
    semester: 'Fall 2024 (Semester 5)',
    facultyName: 'Prof. Marcus Ray',
    facultyEmail: 'marcus.ray@faculty.campus.edu',
    room: 'Systems Hall LH-102',
    totalSessions: 40,
    scheduleSummary: 'Mon & Thu 02:00 PM - 03:15 PM',
    syllabusTopics: ['Lexical Analysis & Flex', 'LR/LALR Parsing & Bison', 'Type Checking & Semantic AST', 'Target Machine Code Gen']
  },
  {
    id: 'cs-505',
    code: 'CS-505',
    name: 'Cloud Computing Lab',
    department: 'Practical Wing',
    credits: 2.0,
    semester: 'Fall 2024 (Semester 5)',
    facultyName: 'Dr. Priya Nair',
    facultyEmail: 'priya.nair@faculty.campus.edu',
    room: 'Cloud Center 401',
    totalSessions: 24,
    scheduleSummary: 'Tuesday 02:00 PM - 05:00 PM',
    syllabusTopics: ['Kubernetes Orch & Helm', 'Istio Service Meshes', 'Serverless Functions', 'Distributed Tracing']
  },
  {
    id: 'hs-301',
    code: 'HS-301',
    name: 'Professional Ethics & IP',
    department: 'Humanities & Law',
    credits: 3.0,
    semester: 'Fall 2024 (Semester 5)',
    facultyName: 'Dr. Clara Scott',
    facultyEmail: 'clara.scott@faculty.campus.edu',
    room: 'Humanities Hall 105',
    totalSessions: 30,
    scheduleSummary: 'Friday 10:00 AM - 11:30 AM',
    syllabusTopics: ['Software Copyright & Patents', 'Algorithmic Bias & Fair AI', 'Academic Honor Codes', 'Digital Privacy Rights']
  }
];

export const INITIAL_ATTENDANCE_SUMMARIES: SubjectAttendanceSummary[] = [
  {
    code: 'CS-501',
    name: 'Distributed Systems',
    faculty: 'Dr. Alan Vance • Core Dept',
    totalSessions: 42,
    attended: 38,
    absent: 4,
    odLeave: 2,
    percentage: 90.5,
    targetPercentage: 75.0,
    status: 'Safe'
  },
  {
    code: 'CS-502',
    name: 'Advanced Algorithms',
    faculty: 'Dr. Sarah Jenkins • Core Dept',
    totalSessions: 48,
    attended: 44,
    absent: 4,
    odLeave: 1,
    percentage: 91.7,
    targetPercentage: 75.0,
    status: 'Safe'
  },
  {
    code: 'CS-503',
    name: 'Machine Learning & AI',
    faculty: 'Prof. Kevin Zhang • Spec Dept',
    totalSessions: 50,
    attended: 42,
    absent: 8,
    odLeave: 3,
    percentage: 84.0,
    targetPercentage: 75.0,
    status: 'Safe'
  },
  {
    code: 'CS-504',
    name: 'Compiler Design',
    faculty: 'Prof. Marcus Ray • Systems Division',
    totalSessions: 40,
    attended: 30,
    absent: 10,
    odLeave: 0,
    percentage: 75.0,
    targetPercentage: 75.0,
    status: 'Warning',
    warningMessage: 'Strict Warning: At 75.0%. Any further unexcused absence will immediately trigger Examination Debarment according to Dean Circular #402.'
  },
  {
    code: 'CS-505',
    name: 'Cloud Computing Lab',
    faculty: 'Dr. Priya Nair • Practical Wing',
    totalSessions: 24,
    attended: 23,
    absent: 1,
    odLeave: 1,
    percentage: 95.8,
    targetPercentage: 75.0,
    status: 'Exceptional'
  },
  {
    code: 'HS-301',
    name: 'Professional Ethics & IP',
    faculty: 'Dr. Clara Scott • Humanities',
    totalSessions: 30,
    attended: 25,
    absent: 5,
    odLeave: 0,
    percentage: 83.3,
    targetPercentage: 75.0,
    status: 'Safe'
  }
];

export const INITIAL_ASSIGNMENTS: Assignment[] = [
  {
    id: 'assign-1',
    code: 'CS-501',
    title: 'Raft Consensus Algorithm & Leader Election in Go',
    subjectCode: 'CS-501',
    subjectName: 'Distributed Systems',
    facultyId: 'faculty_alan_vance',
    facultyName: 'Dr. Alan Vance',
    description: 'Implement state machine replication, heartbeat mechanism, term leases, and leader election protocol in Go. Pass test suite without race conditions.',
    dueDate: 'Tomorrow, 11:59 PM',
    daysRemaining: 'Urgent (18 hrs)',
    maxMarks: 100,
    gradeWeightage: '15% Grade',
    priority: 'urgent',
    completionStage: '60% In Progress',
    completionPercent: 60,
    assets: [
      { name: 'raft_spec_v2.4.pdf', size: '1.4 MB', type: 'pdf' },
      { name: 'starter_code_skeleton.zip', size: '850 KB', type: 'zip' }
    ],
    templateRepoUrl: 'https://github.com/uni-cs501/lab3-raft',
    requirements: [
      'Heartbeat ping RPC passing',
      'Leader failover election within 300ms',
      'Log repair and append entries agreement'
    ]
  },
  {
    id: 'assign-2',
    code: 'CS-504',
    title: 'Lexical Analyzer & Syntax Tree Construction',
    subjectCode: 'CS-504',
    subjectName: 'Compiler Design',
    facultyId: 'faculty_marcus_ray',
    facultyName: 'Prof. Marcus Ray',
    description: 'Construct Lex/Flex token patterns and Yacc/Bison Grammar for mini-C subset with detailed AST serialization.',
    dueDate: 'Nov 12, 2024 • 5:00 PM',
    daysRemaining: '5 days left',
    maxMarks: 100,
    gradeWeightage: '10% Grade',
    priority: 'medium',
    completionStage: 'Not Started',
    completionPercent: 0,
    assets: [
      { name: 'bison_grammar_guide.pdf', size: '940 KB', type: 'pdf' },
      { name: 'git.uni.edu/cs504/lab2', size: 'Repo', type: 'code' }
    ],
    templateRepoUrl: 'https://github.com/uni-cs504/lab2-parser'
  },
  {
    id: 'assign-3',
    code: 'CS-503',
    title: 'Transfer Learning on ImageNet using PyTorch',
    subjectCode: 'CS-503',
    subjectName: 'Machine Learning & AI',
    facultyId: 'faculty_kevin_zhang',
    facultyName: 'Prof. Kevin Zhang',
    description: 'Fine-tune ResNet-50 vs EfficientNet-B2 architectures. Compare Top-1 accuracy, confusion matrix, and inference latencies.',
    dueDate: 'Nov 16, 2024 • 11:59 PM',
    daysRemaining: '9 days left',
    maxMarks: 100,
    gradeWeightage: '20% Grade',
    priority: 'normal',
    completionStage: 'Draft Saved (v1.2)',
    completionPercent: 45,
    assets: [
      { name: 'imagenet_subset_labels.json', size: '3.2 MB', type: 'json' },
      { name: 'pytorch_baseline.ipynb', size: '420 KB', type: 'ipynb' }
    ]
  },
  {
    id: 'assign-4',
    code: 'CS-502',
    title: 'Edmonds-Karp Maximum Flow Network Solver',
    subjectCode: 'CS-502',
    subjectName: 'Advanced Algorithms',
    facultyId: 'faculty_sarah_jenkins',
    facultyName: 'Dr. Sarah Jenkins',
    description: 'Implement residual graph flow augmentation and compare against Dinic algorithm on random bipartite matching graphs.',
    dueDate: 'Nov 24, 2024 • 11:59 PM',
    daysRemaining: '17 days left',
    maxMarks: 100,
    gradeWeightage: '15% Grade',
    priority: 'normal',
    completionStage: 'Not Started',
    completionPercent: 0
  }
];

export const INITIAL_SUBMISSIONS: Submission[] = [
  {
    id: 'sub-1',
    assignmentId: 'assign-prev-1',
    assignmentTitle: 'MapReduce WordCount & Fault Tolerant Worker',
    subjectCode: 'CS-501',
    studentId: 'student_elena_vance',
    studentName: 'Elena Vance',
    studentNumber: '#CS-2022-8492',
    submittedAt: 'Oct 19, 10:45 PM',
    dueDate: 'Oct 20',
    status: 'graded',
    fileName: 'elena_vance_mapreduce_v2.tar.gz',
    fileSize: '4.8 MB',
    score: 98,
    maxScore: 100,
    letterGrade: 'A+',
    feedback: 'Exemplary worker failover handling with graceful heartbeat recovery. Clean Go concurrency constructs.',
    honorCodeAccepted: true
  },
  {
    id: 'sub-2',
    assignmentId: 'assign-prev-2',
    assignmentTitle: 'K-Means & PCA High-Dimensional Clustering',
    subjectCode: 'CS-503',
    studentId: 'student_elena_vance',
    studentName: 'Elena Vance',
    studentNumber: '#CS-2022-8492',
    submittedAt: 'Oct 14, 04:12 PM',
    dueDate: 'Oct 14',
    status: 'graded',
    fileName: 'elena_clustering_notebook.ipynb',
    fileSize: '12.4 MB',
    score: 92,
    maxScore: 100,
    letterGrade: 'A',
    feedback: 'Solid dimensional variance visualization. Slight convergence plateau on 50-cluster edge case.',
    honorCodeAccepted: true
  },
  {
    id: 'sub-3',
    assignmentId: 'assign-prev-3',
    assignmentTitle: 'Finite Automata Simulator (NFA to DFA Conversion)',
    subjectCode: 'CS-504',
    studentId: 'student_elena_vance',
    studentName: 'Elena Vance',
    studentNumber: '#CS-2022-8492',
    submittedAt: 'Oct 04, 11:15 PM',
    dueDate: 'Oct 05',
    status: 'graded',
    fileName: 'nfa_dfa_subset_construction.c',
    fileSize: '280 KB',
    score: 88,
    maxScore: 100,
    letterGrade: 'B+',
    feedback: 'Correct state transition matrices. Minor memory leak detected on large epsilon transitions.',
    honorCodeAccepted: true
  },
  {
    id: 'sub-4',
    assignmentId: 'assign-prev-4',
    assignmentTitle: 'Microservices on Kubernetes with Helm & Istio',
    subjectCode: 'CS-505',
    studentId: 'student_elena_vance',
    studentName: 'Elena Vance',
    studentNumber: '#CS-2022-8492',
    submittedAt: 'Oct 27, 08:30 PM',
    dueDate: 'Oct 28',
    status: 'under_review',
    fileName: 'cloud_lab_manifests.zip',
    fileSize: '2.1 MB',
    notes: 'Includes canary deployment and mutual TLS configuration test logs.',
    honorCodeAccepted: true
  }
];

export const INITIAL_EXAMS: Exam[] = [
  {
    id: 'exam-1',
    paperCode: 'PAPER 01',
    subjectCode: 'CS-501',
    subjectName: 'Distributed Systems',
    credits: 4.0,
    date: 'Thu, Nov 14',
    time: '10:00 AM – 12:00 PM',
    durationMinutes: 120,
    venue: 'Hall LH-101',
    seatDesk: 'Desk: D-14',
    invigilator: 'Prof. Alan Vance',
    examType: 'mid_term',
    instructions: 'Chapters 1–5. Closed book. Non-programmable scientific calculator allowed.',
    syllabusCoverage: 'Consensus protocols, RPC architectures, Lamport timestamps, replication.'
  },
  {
    id: 'exam-2',
    paperCode: 'PAPER 02',
    subjectCode: 'CS-502',
    subjectName: 'Advanced Algorithms',
    credits: 4.0,
    date: 'Mon, Nov 18',
    time: '10:00 AM – 12:00 PM',
    durationMinutes: 120,
    venue: 'Block A, Rm 204',
    seatDesk: 'Desk: A-22',
    invigilator: 'Dr. Sarah Jenkins',
    examType: 'mid_term',
    instructions: 'Dynamic programming & Network flow graphs. Standard drafting kit permissible.',
    syllabusCoverage: 'Ford-Fulkerson, push-relabel, randomized algorithms, string matching.'
  },
  {
    id: 'exam-3',
    paperCode: 'PAPER 03',
    subjectCode: 'CS-503',
    subjectName: 'Machine Learning & AI',
    credits: 4.0,
    date: 'Wed, Nov 20',
    time: '02:00 PM – 04:00 PM',
    durationMinutes: 120,
    venue: 'Turing Aud.',
    seatDesk: 'Desk: T-08',
    invigilator: 'Dr. H. Zimmerman',
    examType: 'mid_term',
    instructions: 'Includes statistical tables. 1 handwritten A4 formula sheet permitted.',
    syllabusCoverage: 'Supervised loss functions, gradient descent mechanics, CNN kernel design.'
  },
  {
    id: 'exam-4',
    paperCode: 'PAPER 04',
    subjectCode: 'CS-504',
    subjectName: 'Compiler Design',
    credits: 4.0,
    date: 'Fri, Nov 22',
    time: '10:00 AM – 12:00 PM',
    durationMinutes: 120,
    venue: 'Hall LH-102',
    seatDesk: 'Desk: D-31',
    invigilator: 'Prof. Maya Chen',
    examType: 'mid_term',
    instructions: 'Lexical analysis, LR parsing, and syntax-directed translation matrices.',
    syllabusCoverage: 'Grammar disambiguation, FIRST & FOLLOW sets, LL(1) parse tables.'
  }
];

export const INITIAL_TRANSCRIPTS: SemesterTranscript[] = [
  {
    semesterId: 'sem-4',
    semesterName: 'Semester 4 (Spring 2024)',
    academicYear: '2023-2024',
    sgpa: 3.76,
    publishedDate: 'Published Jun 2024',
    controllerHash: '#7F04-BC99-E5',
    creditsRegistered: 21,
    creditsEarned: 21,
    courses: [
      {
        code: 'CS-401',
        title: 'Database Engineering',
        faculty: 'Prof. Maria Gonzales',
        credits: 4.0,
        internalMarks: 38,
        endSemMarks: 54,
        totalMarks: 92,
        gradePoint: 10.0,
        letterGrade: 'A+',
        status: 'Pass'
      },
      {
        code: 'CS-402',
        title: 'Computer Networks',
        faculty: 'Dr. Kenneth Wu',
        credits: 4.0,
        internalMarks: 35,
        endSemMarks: 50,
        totalMarks: 85,
        gradePoint: 9.0,
        letterGrade: 'A',
        status: 'Pass'
      },
      {
        code: 'CS-403',
        title: 'Theory of Computation',
        faculty: 'Dr. Robert Langlands',
        credits: 3.0,
        internalMarks: 32,
        endSemMarks: 46,
        totalMarks: 78,
        gradePoint: 8.0,
        letterGrade: 'B+',
        status: 'Pass'
      },
      {
        code: 'CS-404',
        title: 'Web & Mobile Systems',
        faculty: 'Prof. Nathan Cole',
        credits: 4.0,
        internalMarks: 39,
        endSemMarks: 56,
        totalMarks: 95,
        gradePoint: 10.0,
        letterGrade: 'A+',
        status: 'Pass'
      },
      {
        code: 'CS-405',
        title: 'Operating Systems Lab',
        faculty: 'Dr. Alex Mitchell',
        credits: 2.0,
        internalMarks: 38,
        endSemMarks: 58,
        totalMarks: 96,
        gradePoint: 10.0,
        letterGrade: 'A+',
        status: 'Pass'
      }
    ]
  },
  {
    semesterId: 'sem-3',
    semesterName: 'Semester 3 (Fall 2023)',
    academicYear: '2023-2024',
    sgpa: 3.78,
    publishedDate: 'Published Jan 2024',
    controllerHash: '#3B12-EF44-A9',
    creditsRegistered: 20,
    creditsEarned: 20,
    courses: [
      {
        code: 'CS-301',
        title: 'Data Structures & Algorithms',
        faculty: 'Dr. Sarah Jenkins',
        credits: 4.0,
        internalMarks: 37,
        endSemMarks: 55,
        totalMarks: 92,
        gradePoint: 10.0,
        letterGrade: 'A+',
        status: 'Pass'
      },
      {
        code: 'CS-302',
        title: 'Computer Architecture & Org',
        faculty: 'Prof. Kevin Zhang',
        credits: 4.0,
        internalMarks: 34,
        endSemMarks: 52,
        totalMarks: 86,
        gradePoint: 9.0,
        letterGrade: 'A',
        status: 'Pass'
      },
      {
        code: 'MA-301',
        title: 'Discrete Mathematics',
        faculty: 'Dr. Priya Nair',
        credits: 4.0,
        internalMarks: 36,
        endSemMarks: 50,
        totalMarks: 86,
        gradePoint: 9.0,
        letterGrade: 'A',
        status: 'Pass'
      },
      {
        code: 'CS-303',
        title: 'Object Oriented Programming',
        faculty: 'Prof. Marcus Ray',
        credits: 4.0,
        internalMarks: 38,
        endSemMarks: 53,
        totalMarks: 91,
        gradePoint: 10.0,
        letterGrade: 'A+',
        status: 'Pass'
      }
    ]
  },
  {
    semesterId: 'sem-2',
    semesterName: 'Semester 2 (Spring 2023)',
    academicYear: '2022-2023',
    sgpa: 3.72,
    publishedDate: 'Published Jun 2023',
    controllerHash: '#2A99-D821-C1',
    creditsRegistered: 22,
    creditsEarned: 22,
    courses: []
  },
  {
    semesterId: 'sem-1',
    semesterName: 'Semester 1 (Fall 2022)',
    academicYear: '2022-2023',
    sgpa: 3.65,
    publishedDate: 'Published Jan 2023',
    controllerHash: '#1F00-A710-B4',
    creditsRegistered: 21,
    creditsEarned: 21,
    courses: []
  }
];

export const INITIAL_NOTIFICATIONS: NotificationItem[] = [
  {
    id: 'notif-1',
    recipientId: 'student_elena_vance',
    title: 'Mid-Term Hall Tickets Released',
    message: 'Exam Hall Tickets for Fall 2024 Mid-Terms are now ready for validation. Please print a physical copy prior to Nov 14.',
    category: 'exam',
    timestamp: '2 hours ago',
    read: false,
    priority: 'high',
    actionText: 'Download Hall Ticket (PDF)'
  },
  {
    id: 'notif-2',
    recipientId: 'student_elena_vance',
    title: 'Guest Lecture: Cloud Infrastructure at Hyperscale',
    message: 'Delivered by AWS Principal Solutions Architect. Venue: University Main Auditorium A this Friday at 3:00 PM.',
    category: 'announcement',
    timestamp: 'Yesterday at 4:15 PM',
    read: false,
    priority: 'normal'
  },
  {
    id: 'notif-3',
    recipientId: 'student_elena_vance',
    title: 'Library System: Book Renewal Reminder',
    message: 'Introduction to Algorithms (Cormen et al.) is due Nov 5. Auto-renew enabled once.',
    category: 'system',
    timestamp: '2 days ago',
    read: true,
    priority: 'normal',
    actionText: 'Renew for 14 More Days'
  },
  {
    id: 'notif-4',
    recipientId: 'student_elena_vance',
    title: 'Attendance Alert: CS-504 Boundary Reached',
    message: 'Your current attendance in Compiler Design is exactly 75.0%. Keep attending all scheduled sessions to avoid exam debarment.',
    category: 'attendance',
    timestamp: '3 days ago',
    read: true,
    priority: 'high'
  }
];

export const INITIAL_MESSAGES: MessageItem[] = [
  {
    id: 'msg-1',
    conversationId: 'conv-alan-elena',
    senderId: 'faculty_alan_vance',
    senderName: 'Dr. Alan Vance',
    senderRole: 'faculty',
    recipientId: 'student_elena_vance',
    recipientName: 'Elena Vance',
    content: 'Hi Elena, your question on Raft log compaction during yesterday\'s lecture was spot on. I have uploaded the reference paper to the course assets folder.',
    timestamp: 'Yesterday, 11:20 AM',
    read: true
  },
  {
    id: 'msg-2',
    conversationId: 'conv-alan-elena',
    senderId: 'student_elena_vance',
    senderName: 'Elena Vance',
    senderRole: 'student',
    recipientId: 'faculty_alan_vance',
    recipientName: 'Dr. Alan Vance',
    content: 'Thank you Professor! I am testing the snapshot restore RPC in Go and the supplementary paper clarifies the leader leases completely.',
    timestamp: 'Yesterday, 12:45 PM',
    read: true
  },
  {
    id: 'msg-3',
    conversationId: 'conv-alan-elena',
    senderId: 'faculty_alan_vance',
    senderName: 'Dr. Alan Vance',
    senderRole: 'faculty',
    recipientId: 'student_elena_vance',
    recipientName: 'Elena Vance',
    content: 'Great. Let me know if you run into any deadlock issues during term transitions.',
    timestamp: 'Today, 08:45 AM',
    read: false
  },
  {
    id: 'msg-4',
    conversationId: 'conv-sarah-elena',
    senderId: 'faculty_sarah_jenkins',
    senderName: 'Dr. Sarah Jenkins',
    senderRole: 'faculty',
    recipientId: 'student_elena_vance',
    recipientName: 'Elena Vance',
    content: 'Hi Elena, don\'t forget to sign up for the algorithmic competition track before Thursday noon.',
    timestamp: '2 days ago',
    read: true
  }
];

export const INITIAL_EXEMPTIONS: LeaveExemption[] = [
  {
    id: 'ex-1',
    studentId: 'student_elena_vance',
    studentName: 'Elena Vance',
    studentNumber: '#CS-2022-8492',
    type: 'medical',
    title: 'Medical Leave (Flu & Fever)',
    reason: 'Prescribed medical rest and quarantine due to seasonal viral fever.',
    sessionsCount: 2,
    dateRange: 'Oct 14, 2024 • 2 Sessions Excused',
    status: 'approved',
    submittedAt: '2024-10-14T08:00:00Z'
  },
  {
    id: 'ex-2',
    studentId: 'student_elena_vance',
    studentName: 'Elena Vance',
    studentNumber: '#CS-2022-8492',
    type: 'on_duty',
    title: 'Hackathon Inter-College OD',
    reason: 'Representing university at ACM National Collegiate Hackathon semifinals.',
    sessionsCount: 4,
    dateRange: 'Sep 22, 2024 • 4 Sessions Excused',
    status: 'approved',
    submittedAt: '2024-09-20T10:30:00Z'
  },
  {
    id: 'ex-3',
    studentId: 'student_elena_vance',
    studentName: 'Elena Vance',
    studentNumber: '#CS-2022-8492',
    type: 'sports',
    title: 'Athletics Meet Representation',
    reason: 'State University Athletic Track & Field championship trials.',
    sessionsCount: 2,
    dateRange: 'Nov 04, 2024 • In Review',
    status: 'pending',
    submittedAt: '2024-10-28T14:15:00Z'
  }
];

export const INITIAL_TIMETABLE_TODAY: TimetableSlot[] = [
  {
    id: 'time-1',
    day: 'Thursday',
    startTime: '09:00 AM',
    endTime: '10:15 AM',
    subjectCode: 'CS-502',
    subjectName: 'Advanced Algorithms',
    facultyName: 'Prof. Dr. Sarah Jenkins',
    room: 'CS-204',
    type: 'Lecture',
    status: 'Attended'
  },
  {
    id: 'time-2',
    day: 'Thursday',
    startTime: '10:30 AM',
    endTime: '11:45 AM',
    subjectCode: 'CS-501',
    subjectName: 'Distributed Systems',
    facultyName: 'Dr. Alan Vance',
    room: 'Lecture Hall LH-302',
    type: 'Lecture',
    topic: 'Raft Consensus',
    status: 'NOW'
  },
  {
    id: 'time-3',
    day: 'Thursday',
    startTime: '01:30 PM',
    endTime: '03:30 PM',
    subjectCode: 'CS-503',
    subjectName: 'Machine Learning Lab',
    facultyName: 'Prof. Kevin Zhang',
    room: 'Computing Lab 3',
    type: 'Lab',
    status: 'Upcoming'
  },
  {
    id: 'time-4',
    day: 'Thursday',
    startTime: '04:00 PM',
    endTime: '05:00 PM',
    subjectCode: 'OFF-HOURS',
    subjectName: 'Faculty Office Hours',
    facultyName: 'Dr. Sarah Jenkins',
    room: 'Faculty Tower 4B',
    type: 'Office Hours',
    status: 'Optional'
  }
];

export const WEEKLY_TIMETABLE: Record<string, TimetableSlot[]> = {
  Monday: [
    {
      id: 'mon-1',
      day: 'Monday',
      startTime: '09:00 AM',
      endTime: '10:15 AM',
      subjectCode: 'CS-502',
      subjectName: 'Advanced Algorithms',
      facultyName: 'Dr. Sarah Jenkins',
      room: 'CS-204',
      type: 'Lecture'
    },
    {
      id: 'mon-2',
      day: 'Monday',
      startTime: '11:00 AM',
      endTime: '12:30 PM',
      subjectCode: 'CS-504',
      subjectName: 'Compiler Design',
      facultyName: 'Prof. Marcus Ray',
      room: 'LH-102',
      type: 'Lecture'
    },
    {
      id: 'mon-3',
      day: 'Monday',
      startTime: '02:00 PM',
      endTime: '04:00 PM',
      subjectCode: 'CS-503',
      subjectName: 'Machine Learning Theory',
      facultyName: 'Prof. Kevin Zhang',
      room: 'Computing Lab 3',
      type: 'Lecture'
    }
  ],
  Tuesday: [
    {
      id: 'tue-1',
      day: 'Tuesday',
      startTime: '10:30 AM',
      endTime: '11:45 AM',
      subjectCode: 'CS-501',
      subjectName: 'Distributed Systems',
      facultyName: 'Dr. Alan Vance',
      room: 'LH-302',
      type: 'Lecture'
    },
    {
      id: 'tue-2',
      day: 'Tuesday',
      startTime: '02:00 PM',
      endTime: '05:00 PM',
      subjectCode: 'CS-505',
      subjectName: 'Cloud Computing Lab',
      facultyName: 'Dr. Priya Nair',
      room: 'Cloud Center 401',
      type: 'Lab'
    }
  ],
  Wednesday: [
    {
      id: 'wed-1',
      day: 'Wednesday',
      startTime: '09:00 AM',
      endTime: '10:15 AM',
      subjectCode: 'CS-502',
      subjectName: 'Advanced Algorithms',
      facultyName: 'Dr. Sarah Jenkins',
      room: 'CS-204',
      type: 'Lecture'
    },
    {
      id: 'wed-2',
      day: 'Wednesday',
      startTime: '01:30 PM',
      endTime: '03:30 PM',
      subjectCode: 'CS-503',
      subjectName: 'Machine Learning Lab',
      facultyName: 'Prof. Kevin Zhang',
      room: 'Computing Lab 3',
      type: 'Lab'
    }
  ],
  Thursday: INITIAL_TIMETABLE_TODAY,
  Friday: [
    {
      id: 'fri-1',
      day: 'Friday',
      startTime: '10:00 AM',
      endTime: '11:30 AM',
      subjectCode: 'HS-301',
      subjectName: 'Professional Ethics & IP',
      facultyName: 'Dr. Clara Scott',
      room: 'Humanities Hall 105',
      type: 'Lecture'
    },
    {
      id: 'fri-2',
      day: 'Friday',
      startTime: '02:00 PM',
      endTime: '03:30 PM',
      subjectCode: 'CS-504',
      subjectName: 'Compiler Design Lab',
      facultyName: 'Prof. Marcus Ray',
      room: 'Systems Lab 2',
      type: 'Lab'
    }
  ],
  Saturday: [
    {
      id: 'sat-1',
      day: 'Saturday',
      startTime: '10:00 AM',
      endTime: '12:00 PM',
      subjectCode: 'SEMINAR',
      subjectName: 'Industry Colloquium & Career Mentorship',
      facultyName: 'Visiting Industry Experts',
      room: 'Auditorium Hall B',
      type: 'Tutorial'
    }
  ]
};
