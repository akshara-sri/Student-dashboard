import React from 'react';
import { X, QrCode, Shield, Download, CheckCircle, Smartphone } from 'lucide-react';
import { UserProfile } from '../../types';

interface DigitalIdModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserProfile | null;
}

export const DigitalIdModal: React.FC<DigitalIdModalProps> = ({ isOpen, onClose, user }) => {
  if (!isOpen || !user) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-md w-full shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden">
        {/* Header Bar */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <Smartphone className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
            <h3 className="font-bold text-slate-900 dark:text-white text-base">Digital Identity Pass</h3>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center text-slate-400 hover:text-slate-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* ID Card Front View */}
        <div className="p-6">
          <div className="relative rounded-2xl bg-gradient-to-br from-indigo-700 via-indigo-600 to-indigo-900 text-white p-6 shadow-xl overflow-hidden">
            {/* Holographic Watermark */}
            <div className="absolute -right-12 -top-12 w-48 h-48 rounded-full bg-white/5 blur-2xl pointer-events-none" />
            <div className="absolute right-4 bottom-4 opacity-15">
              <Shield className="w-32 h-32" />
            </div>

            {/* Top Bar */}
            <div className="flex items-start justify-between relative z-10 mb-6">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-white/10 backdrop-blur-md flex items-center justify-center border border-white/20">
                  <Shield className="w-5 h-5 text-indigo-200" />
                </div>
                <div>
                  <h4 className="font-extrabold text-sm tracking-wide uppercase text-indigo-100">National University</h4>
                  <p className="text-[10px] text-indigo-200 tracking-wider">SCHOOL OF COMPUTING & AI</p>
                </div>
              </div>
              <span className="px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider bg-emerald-400/20 text-emerald-300 border border-emerald-400/30 flex items-center gap-1">
                <CheckCircle className="w-3 h-3" />
                Active
              </span>
            </div>

            {/* Photo & Details */}
            <div className="flex items-center gap-5 relative z-10 mb-6">
              <img
                src={user.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150'}
                alt={user.displayName}
                className="w-20 h-24 rounded-xl object-cover ring-2 ring-white/40 shadow-md"
              />
              <div className="space-y-1">
                <h3 className="text-lg font-black leading-tight text-white">{user.displayName}</h3>
                <p className="text-xs font-mono font-semibold text-indigo-200">{user.studentId || user.facultyId || '#CS-2022-8492'}</p>
                <div className="text-[11px] text-indigo-100 font-medium pt-1">
                  <p>Program: <span className="font-semibold text-white">B.Tech Computer Science</span></p>
                  <p>Term: <span className="font-semibold text-white">Fall 2024 (Semester 5)</span></p>
                  <p>Valid Thru: <span className="font-semibold text-white">June 2026</span></p>
                </div>
              </div>
            </div>

            {/* Barcode & Security strip */}
            <div className="relative z-10 pt-4 border-t border-white/15 flex items-center justify-between">
              <div className="space-y-1">
                <div className="flex gap-1 h-6 items-end">
                  {[2, 4, 1, 3, 2, 5, 1, 4, 2, 3, 5, 2, 1, 3, 4, 2, 5, 1, 3].map((h, i) => (
                    <div key={i} className="w-1 bg-white/80 rounded-xs" style={{ height: `${h * 4 + 6}px` }} />
                  ))}
                </div>
                <p className="text-[9px] font-mono tracking-widest text-indigo-200">ISO/IEC 7810 ID-1 • AUTH SECURE</p>
              </div>

              <div className="w-12 h-12 rounded-lg bg-white p-1 flex items-center justify-center shadow-md">
                <QrCode className="w-full h-full text-slate-900" />
              </div>
            </div>
          </div>

          <div className="mt-5 space-y-2">
            <button
              onClick={() => window.print()}
              className="w-full py-2.5 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-sm flex items-center justify-center gap-2 shadow-md shadow-indigo-100 dark:shadow-none transition-colors"
            >
              <Download className="w-4 h-4" />
              <span>Save & Download Digital Pass</span>
            </button>
            <p className="text-[11px] text-center text-slate-400">
              Valid for campus library entry, laboratory access, and examination invigilation.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
