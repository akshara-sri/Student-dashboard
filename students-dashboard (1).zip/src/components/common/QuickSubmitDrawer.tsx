import React, { useState } from 'react';
import { UploadCloud, CheckCircle2, FileText, Send, Sparkles } from 'lucide-react';
import confetti from 'canvas-confetti';
import { Assignment } from '../../types';
import { dataService } from '../../services/dataService';
import { useAuth } from '../../context/AuthContext';

interface QuickSubmitDrawerProps {
  assignments: Assignment[];
  onSubmissionComplete: () => void;
  defaultAssignmentId?: string;
}

export const QuickSubmitDrawer: React.FC<QuickSubmitDrawerProps> = ({
  assignments,
  onSubmissionComplete,
  defaultAssignmentId
}) => {
  const { currentUser } = useAuth();
  const [selectedId, setSelectedId] = useState(defaultAssignmentId || assignments[0]?.id || '');
  const [fileName, setFileName] = useState('raft_leader_election_solution.tar.gz');
  const [fileSize, setFileSize] = useState('3.8 MB');
  const [notes, setNotes] = useState('All tests passing in -race mode. Implemented randomized election jitter with 150-300ms window.');
  const [honorChecked, setHonorChecked] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);

  const activeAssign = assignments.find(a => a.id === selectedId) || assignments[0];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser || !honorChecked) return;
    setSubmitting(true);

    try {
      await dataService.submitAssignment({
        assignmentId: activeAssign.id,
        studentId: currentUser.uid,
        studentName: currentUser.displayName,
        studentNumber: currentUser.studentId || '#CS-2022-8492',
        fileName,
        fileSize,
        notes,
        honorCodeAccepted: honorChecked
      });

      // Fire celebratory confetti!
      confetti({
        particleCount: 80,
        spread: 60,
        origin: { y: 0.7 }
      });

      setSuccess(true);
      setTimeout(() => {
        setSuccess(false);
        onSubmissionComplete();
      }, 1600);
    } catch (err) {
      console.error(err);
    } finally {
      setSubmitting(false);
    }
  };

  const handleFileDrop = (e: React.DragEvent) => {
    e.preventDefault();
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const f = e.dataTransfer.files[0];
      setFileName(f.name);
      setFileSize((f.size / (1024 * 1024)).toFixed(1) + ' MB');
    }
  };

  return (
    <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
      <div className="flex items-center justify-between pb-1 border-b border-slate-100 dark:border-slate-800">
        <div className="flex items-center gap-2">
          <UploadCloud className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
          <h3 className="font-bold text-slate-900 dark:text-white text-sm">Quick Submit Drawer</h3>
        </div>
        <span className="text-[10px] font-bold tracking-wider uppercase px-2 py-0.5 rounded-md bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400">
          Fast Lane
        </span>
      </div>

      {success ? (
        <div className="py-10 text-center space-y-3 animate-in fade-in zoom-in-95">
          <div className="w-12 h-12 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-md shadow-emerald-100">
            <CheckCircle2 className="w-6 h-6" />
          </div>
          <h4 className="text-sm font-bold text-slate-900 dark:text-white">Deliverable Submitted!</h4>
          <p className="text-xs text-slate-500">Your commit and tarball were submitted and queued for evaluation.</p>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1.5">
              Target Assignment
            </label>
            <select
              value={selectedId}
              onChange={(e) => setSelectedId(e.target.value)}
              className="w-full text-xs font-semibold px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:border-indigo-500"
            >
              {assignments.map((a) => (
                <option key={a.id} value={a.id}>
                  {a.subjectCode}: {a.title}
                </option>
              ))}
            </select>
          </div>

          {/* Upload Drop Zone */}
          <div
            onDragOver={(e) => e.preventDefault()}
            onDrop={handleFileDrop}
            className="border-2 border-dashed border-indigo-200 dark:border-slate-700 hover:border-indigo-500 rounded-2xl p-5 text-center bg-indigo-50/30 dark:bg-slate-800/40 transition-colors cursor-pointer group"
            onClick={() => {
              const input = document.createElement('input');
              input.type = 'file';
              input.onchange = (e: any) => {
                const f = e.target.files[0];
                if (f) {
                  setFileName(f.name);
                  setFileSize((f.size / (1024 * 1024)).toFixed(1) + ' MB');
                }
              };
              input.click();
            }}
          >
            <div className="w-10 h-10 rounded-full bg-indigo-100 dark:bg-indigo-900/50 text-indigo-600 dark:text-indigo-400 flex items-center justify-center mx-auto mb-2 group-hover:scale-105 transition-transform">
              <UploadCloud className="w-5 h-5" />
            </div>
            <p className="text-xs font-bold text-slate-800 dark:text-slate-200">
              Click to upload or drag files
            </p>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Accepts ZIP, TAR.GZ, PDF, IPYNB (Max 50MB)
            </p>

            {fileName && (
              <div className="mt-3 inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-800 dark:text-slate-200 shadow-2xs">
                <FileText className="w-3.5 h-3.5 text-indigo-500" />
                <span>{fileName}</span>
                <span className="text-slate-400 text-[10px]">({fileSize})</span>
              </div>
            )}
          </div>

          {/* Note to TA */}
          <div>
            <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1.5">
              Note to Teaching Assistant
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Specify node failover test flags, execution instructions, or known anomalies..."
              className="w-full text-xs px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:border-indigo-500"
            />
          </div>

          {/* Honor Code Checkbox */}
          <label className="flex items-start gap-2.5 text-xs text-slate-600 dark:text-slate-400 cursor-pointer select-none">
            <input
              type="checkbox"
              checked={honorChecked}
              onChange={(e) => setHonorChecked(e.target.checked)}
              className="mt-0.5 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500"
            />
            <span className="text-[11px] leading-relaxed">
              I certify that this submission represents my original academic work in compliance with the University Code of Conduct.
            </span>
          </label>

          <div className="flex items-center gap-2 pt-1">
            <button
              type="button"
              onClick={() => alert('Draft checkpoint saved locally.')}
              className="flex-1 py-2 px-3 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors text-center"
            >
              Save as Draft
            </button>
            <button
              type="submit"
              disabled={submitting || !honorChecked}
              className="flex-1 py-2 px-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white text-xs font-semibold flex items-center justify-center gap-1.5 shadow-md shadow-indigo-200 dark:shadow-none transition-colors"
            >
              <Send className="w-3.5 h-3.5" />
              <span>{submitting ? 'Submitting...' : 'Submit Work'}</span>
            </button>
          </div>
        </form>
      )}
    </div>
  );
};
