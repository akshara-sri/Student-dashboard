import React, { useState } from 'react';
import { Settings, Bell, Shield, Moon, Sun, RefreshCw, Check } from 'lucide-react';

interface SettingsViewProps {
  darkMode: boolean;
  setDarkMode: (val: boolean) => void;
  onResetData: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  darkMode,
  setDarkMode,
  onResetData
}) => {
  const [emailAlerts, setEmailAlerts] = useState(true);
  const [examReminders, setExamReminders] = useState(true);
  const [attendanceWarnings, setAttendanceWarnings] = useState(true);
  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 1500);
  };

  return (
    <div className="space-y-6 pb-12 max-w-4xl">
      <div>
        <span className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 flex items-center gap-1.5 mb-1">
          <span className="w-2 h-2 rounded-full bg-indigo-600" />
          User Preferences
        </span>
        <h1 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">
          Portal &amp; Security Settings
        </h1>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
          Manage alert frequencies, visual appearance, and security credentials
        </p>
      </div>

      <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-xs space-y-6">
        {/* Appearance */}
        <div className="space-y-3">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white">Interface Appearance</h3>
          <div className="grid grid-cols-2 gap-3 max-w-md">
            <button
              type="button"
              onClick={() => setDarkMode(false)}
              className={`p-3 rounded-2xl border flex items-center justify-between text-xs font-bold transition-all ${
                !darkMode
                  ? 'border-indigo-600 bg-indigo-50/50 text-indigo-600'
                  : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
              }`}
            >
              <div className="flex items-center gap-2">
                <Sun className="w-4 h-4 text-amber-500" />
                <span>Light Theme</span>
              </div>
              {!darkMode && <Check className="w-4 h-4" />}
            </button>

            <button
              type="button"
              onClick={() => setDarkMode(true)}
              className={`p-3 rounded-2xl border flex items-center justify-between text-xs font-bold transition-all ${
                darkMode
                  ? 'border-indigo-600 bg-indigo-950/60 text-indigo-400'
                  : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
              }`}
            >
              <div className="flex items-center gap-2">
                <Moon className="w-4 h-4 text-indigo-400" />
                <span>Dark Theme</span>
              </div>
              {darkMode && <Check className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Notifications */}
        <div className="space-y-3 pt-4 border-t border-slate-100 dark:border-slate-800">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white">Notification Preferences</h3>
          <div className="space-y-3">
            <label className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/50 cursor-pointer">
              <div>
                <p className="text-xs font-bold text-slate-800 dark:text-slate-200">Email Notifications for Grades</p>
                <p className="text-[11px] text-slate-400">Receive instant transcripts upon official board declaration</p>
              </div>
              <input
                type="checkbox"
                checked={emailAlerts}
                onChange={(e) => setEmailAlerts(e.target.checked)}
                className="w-4 h-4 text-indigo-600 rounded"
              />
            </label>

            <label className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/50 cursor-pointer">
              <div>
                <p className="text-xs font-bold text-slate-800 dark:text-slate-200">Exam Hall Ticket &amp; Seating Alerts</p>
                <p className="text-[11px] text-slate-400">Push SMS notifications 24 hours prior to mid-terms and finals</p>
              </div>
              <input
                type="checkbox"
                checked={examReminders}
                onChange={(e) => setExamReminders(e.target.checked)}
                className="w-4 h-4 text-indigo-600 rounded"
              />
            </label>

            <label className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/50 cursor-pointer">
              <div>
                <p className="text-xs font-bold text-slate-800 dark:text-slate-200">Attendance Low Threshold Alarms</p>
                <p className="text-[11px] text-slate-400">Urgent alert when any registered course reaches 75% boundary</p>
              </div>
              <input
                type="checkbox"
                checked={attendanceWarnings}
                onChange={(e) => setAttendanceWarnings(e.target.checked)}
                className="w-4 h-4 text-indigo-600 rounded"
              />
            </label>
          </div>
        </div>

        {/* Data Reset */}
        <div className="space-y-3 pt-4 border-t border-slate-100 dark:border-slate-800">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white">Diagnostic &amp; Demo Utilities</h3>
          <div className="flex items-center justify-between p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40">
            <div>
              <p className="text-xs font-bold text-slate-800 dark:text-slate-200">Reset Local Mock Data Cache</p>
              <p className="text-[11px] text-slate-400">Restore factory demonstration states for attendance, assignments and transcripts</p>
            </div>
            <button
              type="button"
              onClick={onResetData}
              className="px-3.5 py-1.5 rounded-xl border border-slate-300 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5 transition-colors"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Reset State</span>
            </button>
          </div>
        </div>

        <div className="pt-2 flex justify-end">
          <button
            type="button"
            onClick={handleSave}
            className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-md shadow-indigo-200 dark:shadow-none transition-colors"
          >
            {saved ? <Check className="w-4 h-4" /> : null}
            <span>{saved ? 'Preferences Saved' : 'Save Preferences'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
