import React, { useState } from 'react';
import { BookOpen, User, MapPin, Clock, Award, FileText, CheckCircle2, ChevronRight } from 'lucide-react';
import { Course } from '../../types';

interface CoursesViewProps {
  courses: Course[];
}

export const CoursesView: React.FC<CoursesViewProps> = ({ courses }) => {
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);

  return (
    <div className="space-y-6 pb-12">
      {/* Top Header */}
      <div>
        <span className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 flex items-center gap-1.5 mb-1">
          <span className="w-2 h-2 rounded-full bg-indigo-600" />
          Curriculum Syllabus
        </span>
        <h1 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">
          Registered Academic Courses
        </h1>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
          Fall 2024 • 5th Semester B.Tech Computer Science (21 Credits Total)
        </p>
      </div>

      {/* Courses Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {courses.map((course) => (
          <div
            key={course.id}
            className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col justify-between space-y-4 hover:border-indigo-300 transition-all"
          >
            <div>
              <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800 text-[11px] font-bold">
                <span className="font-mono text-indigo-600 dark:text-indigo-400 uppercase">{course.code}</span>
                <span className="text-slate-500 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded-md">
                  {course.credits}.0 Credits
                </span>
              </div>

              <div className="mt-3">
                <h4 className="text-base font-extrabold text-slate-900 dark:text-white leading-snug">
                  {course.name}
                </h4>
                <p className="text-xs text-slate-400 mt-1">{course.department}</p>
              </div>

              <div className="mt-4 space-y-2 text-xs">
                <div className="flex items-center gap-2 text-slate-700 dark:text-slate-300">
                  <User className="w-3.5 h-3.5 text-indigo-500 shrink-0" />
                  <span>{course.facultyName}</span>
                </div>
                <div className="flex items-center gap-2 text-slate-600 dark:text-slate-400">
                  <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <span>{course.room}</span>
                </div>
                {course.scheduleSummary && (
                  <div className="flex items-center gap-2 text-slate-500 text-[11px]">
                    <Clock className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span>{course.scheduleSummary}</span>
                  </div>
                )}
              </div>

              {course.syllabusTopics && (
                <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800">
                  <p className="text-[10px] uppercase font-bold text-slate-400 mb-1.5">Core Syllabus Units</p>
                  <ul className="text-[11px] text-slate-500 space-y-1">
                    {course.syllabusTopics.slice(0, 3).map((topic, i) => (
                      <li key={i} className="flex items-center gap-1.5 truncate">
                        <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 shrink-0" />
                        <span className="truncate">{topic}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>

            <button
              onClick={() => setSelectedCourse(course)}
              className="w-full py-2 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-bold transition-colors flex items-center justify-center gap-1"
            >
              <span>View Full Syllabus &amp; Modules</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        ))}
      </div>

      {/* Syllabus Modal */}
      {selectedCourse && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-lg w-full p-6 space-y-4 border border-slate-200 dark:border-slate-800 shadow-2xl">
            <div className="flex items-start justify-between">
              <div>
                <span className="font-mono text-xs font-bold text-indigo-600 dark:text-indigo-400">
                  {selectedCourse.code} • {selectedCourse.credits}.0 Credits
                </span>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white mt-1">
                  {selectedCourse.name}
                </h3>
                <p className="text-xs text-slate-400">{selectedCourse.facultyName} • {selectedCourse.facultyEmail}</p>
              </div>
              <button
                onClick={() => setSelectedCourse(null)}
                className="text-slate-400 hover:text-slate-600 text-xs font-bold"
              >
                Close
              </button>
            </div>

            <div className="space-y-2 text-xs text-slate-600 dark:text-slate-300">
              <h5 className="font-bold text-slate-900 dark:text-white text-xs">Curriculum Modules:</h5>
              <div className="space-y-1.5">
                {selectedCourse.syllabusTopics?.map((t, idx) => (
                  <div key={idx} className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 flex items-center gap-2">
                    <span className="font-mono font-bold text-indigo-600 dark:text-indigo-400 text-[11px]">Unit {idx + 1}:</span>
                    <span>{t}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                onClick={() => {
                  alert('Syllabus PDF downloaded.');
                  setSelectedCourse(null);
                }}
                className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs"
              >
                Download Syllabus PDF
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
