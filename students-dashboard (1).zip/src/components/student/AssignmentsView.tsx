import React, { useState } from 'react';
import { 
  FileText, 
  Clock, 
  Search, 
  CheckCircle2, 
  Calendar, 
  Download, 
  ExternalLink, 
  ArrowRight,
  Sparkles,
  GitBranch,
  Layers,
  ChevronDown,
  Filter,
  Check
} from 'lucide-react';
import { Assignment, Submission } from '../../types';
import { QuickSubmitDrawer } from '../common/QuickSubmitDrawer';

interface AssignmentsViewProps {
  assignments: Assignment[];
  submissions: Submission[];
  onRefreshData: () => void;
}

export const AssignmentsView: React.FC<AssignmentsViewProps> = ({
  assignments,
  submissions,
  onRefreshData
}) => {
  const [activeTab, setActiveTab] = useState<'all' | 'pending' | 'submitted' | 'graded' | 'overdue'>('all');
  const [courseFilter, setCourseFilter] = useState('all');
  const [searchFilter, setSearchFilter] = useState('');
  const [selectedAssignmentForSubmit, setSelectedAssignmentForSubmit] = useState<string>(assignments[0]?.id || '');
  const [showDetailModal, setShowDetailModal] = useState<Assignment | null>(null);

  // Filtered lists
  const filteredAssignments = assignments.filter((a) => {
    if (courseFilter !== 'all' && a.subjectCode !== courseFilter) return false;
    if (searchFilter && !a.title.toLowerCase().includes(searchFilter.toLowerCase()) && !a.subjectCode.toLowerCase().includes(searchFilter.toLowerCase())) {
      return false;
    }
    if (activeTab === 'pending') return a.completionPercent !== 100;
    if (activeTab === 'submitted') return a.completionPercent === 100;
    if (activeTab === 'graded') return false; // Handled in submissions table
    if (activeTab === 'overdue') return false;
    return true;
  });

  return (
    <div className="space-y-6 pb-12">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 flex items-center gap-1.5 mb-1">
            <span className="w-2 h-2 rounded-full bg-indigo-600" />
            Semester 5 Active Pipeline
          </span>
          <h1 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">
            Coursework & Assignments
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Track deadlines, submit projects, and inspect grading rubrics.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Course filter select */}
          <div className="relative">
            <select
              value={courseFilter}
              onChange={(e) => setCourseFilter(e.target.value)}
              className="text-xs font-semibold px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 shadow-2xs focus:outline-none"
            >
              <option value="all">All Courses</option>
              <option value="CS-501">CS-501 Distributed Systems</option>
              <option value="CS-502">CS-502 Advanced Algorithms</option>
              <option value="CS-503">CS-503 Machine Learning & AI</option>
              <option value="CS-504">CS-504 Compiler Design</option>
              <option value="CS-505">CS-505 Cloud Computing Lab</option>
            </select>
          </div>

          <div className="relative">
            <select
              className="text-xs font-semibold px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 shadow-2xs focus:outline-none"
            >
              <option>Due Date: Earliest First</option>
              <option>Priority: Highest First</option>
              <option>Marks: Highest Weightage</option>
            </select>
          </div>

          <button
            onClick={() => {
              const el = document.getElementById('quick-submit-container');
              el?.scrollIntoView({ behavior: 'smooth' });
            }}
            className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-md shadow-indigo-200 dark:shadow-none transition-colors flex items-center gap-1.5"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Quick Submit</span>
          </button>
        </div>
      </div>

      {/* Filter Tabs & Search Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-slate-200 dark:border-slate-800 pb-3">
        <div className="flex flex-wrap items-center gap-1">
          {[
            { id: 'all', label: 'All Assignments', count: assignments.length },
            { id: 'pending', label: 'Pending / Due', count: 3 },
            { id: 'submitted', label: 'Submitted', count: submissions.length },
            { id: 'graded', label: 'Graded', count: 3 },
            { id: 'overdue', label: 'Overdue', count: 0 },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                activeTab === tab.id
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <span>{tab.label}</span>
              <span className={`text-[10px] px-1.5 py-0.2 rounded-md ${
                activeTab === tab.id ? 'bg-indigo-700 text-white' : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
              }`}>
                {tab.count}
              </span>
            </button>
          ))}
        </div>

        <div className="relative">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchFilter}
            onChange={(e) => setSearchFilter(e.target.value)}
            placeholder="Search assignments, tags, or topics..."
            className="text-xs pl-8 pr-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 w-full sm:w-64 focus:outline-none focus:border-indigo-500"
          />
        </div>
      </div>

      {/* Priority Action Required: 3 Deliverable Cards (Screenshot 3 match) */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-rose-500" />
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              Priority Action Required <span className="text-slate-400 font-normal">• 3 Upcoming Deliverables</span>
            </h3>
          </div>
          <span className="text-[11px] text-slate-400 font-medium">
            Auto-sync with Canvas LMS &amp; GitClassroom
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {/* Card 1: Raft Consensus */}
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col justify-between space-y-4 hover:border-indigo-300 transition-all">
            <div>
              {/* Header badge */}
              <div className="flex items-center justify-between text-[11px] font-bold pb-2 border-b border-slate-100 dark:border-slate-800">
                <span className="text-rose-600 uppercase tracking-wider flex items-center gap-1">
                  • URGENT • DUE TOMORROW 11:59 PM
                </span>
                <span className="text-slate-400 font-semibold">15% Grade</span>
              </div>

              <div className="mt-3">
                <p className="text-[11px] font-extrabold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
                  CS-501 • DISTRIBUTED SYSTEMS
                </p>
                <h4 className="text-base font-extrabold text-slate-900 dark:text-white mt-1 leading-snug">
                  Raft Consensus Algorithm &amp; Leader Election in Go
                </h4>
                <p className="text-xs text-slate-500 mt-2 line-clamp-2 leading-relaxed">
                  Implement state machine replication, heartbeat mechanism, term leases, and log repair failover in Go.
                </p>
              </div>

              {/* Completion Stage */}
              <div className="mt-4 p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 space-y-2">
                <div className="flex items-center justify-between text-xs font-bold">
                  <span className="text-slate-600 dark:text-slate-400">Completion Stage</span>
                  <span className="text-indigo-600 dark:text-indigo-400">60% In Progress</span>
                </div>
                <div className="w-full bg-slate-200 dark:bg-slate-700 h-1.5 rounded-full overflow-hidden">
                  <div className="bg-indigo-600 h-full rounded-full" style={{ width: '60%' }} />
                </div>
                <p className="text-[11px] text-slate-500 flex items-center gap-1">
                  <Check className="w-3 h-3 text-emerald-500 shrink-0" />
                  Heartbeat ping RPC passing • Log repair failing
                </p>
              </div>

              {/* Course Assets */}
              <div className="mt-4 space-y-1.5">
                <p className="text-[10px] uppercase font-bold text-slate-400">Course Assets</p>
                <div className="flex items-center justify-between p-2 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800 text-xs">
                  <div className="flex items-center gap-2">
                    <FileText className="w-3.5 h-3.5 text-rose-500" />
                    <span className="font-semibold text-slate-700 dark:text-slate-300">raft_spec_v2.4.pdf</span>
                  </div>
                  <span className="text-slate-400 text-[10px]">1.4 MB</span>
                </div>
                <div className="flex items-center justify-between p-2 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800 text-xs">
                  <div className="flex items-center gap-2">
                    <Download className="w-3.5 h-3.5 text-indigo-500" />
                    <span className="font-semibold text-slate-700 dark:text-slate-300">starter_code_skeleton.zip</span>
                  </div>
                  <span className="text-slate-400 text-[10px]">850 KB</span>
                </div>
              </div>
            </div>

            <button
              onClick={() => {
                setSelectedAssignmentForSubmit('assign-1');
                const el = document.getElementById('quick-submit-container');
                el?.scrollIntoView({ behavior: 'smooth' });
              }}
              className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md shadow-indigo-200 dark:shadow-none transition-colors"
            >
              Submit Assignment
            </button>
          </div>

          {/* Card 2: Lexical Analyzer */}
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col justify-between space-y-4 hover:border-indigo-300 transition-all">
            <div>
              <div className="flex items-center justify-between text-[11px] font-bold pb-2 border-b border-slate-100 dark:border-slate-800">
                <span className="text-slate-500 uppercase tracking-wider">
                  DUE NOV 12, 2024 • 5 DAYS LEFT
                </span>
                <span className="text-slate-400 font-semibold">10% Grade</span>
              </div>

              <div className="mt-3">
                <p className="text-[11px] font-extrabold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
                  CS-504 • COMPILER DESIGN
                </p>
                <h4 className="text-base font-extrabold text-slate-900 dark:text-white mt-1 leading-snug">
                  Lexical Analyzer &amp; Syntax Tree Construction
                </h4>
                <p className="text-xs text-slate-500 mt-2 line-clamp-2 leading-relaxed">
                  Construct Lex/Flex token patterns and Yacc/Bison Grammar for mini-C subset with AST node serialization.
                </p>
              </div>

              <div className="mt-4 p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 space-y-1">
                <div className="flex items-center justify-between text-xs font-bold">
                  <span className="text-slate-600 dark:text-slate-400">Status</span>
                  <span className="text-slate-500">Not Started</span>
                </div>
                <p className="text-[11px] text-slate-400 flex items-center gap-1">
                  <GitBranch className="w-3 h-3 text-slate-400" />
                  Repository template cloned locally
                </p>
              </div>

              <div className="mt-4 space-y-1.5">
                <p className="text-[10px] uppercase font-bold text-slate-400">Course Assets</p>
                <div className="flex items-center justify-between p-2 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800 text-xs">
                  <div className="flex items-center gap-2">
                    <FileText className="w-3.5 h-3.5 text-rose-500" />
                    <span className="font-semibold text-slate-700 dark:text-slate-300">bison_grammar_guide.pdf</span>
                  </div>
                  <span className="text-slate-400 text-[10px]">940 KB</span>
                </div>
                <div className="flex items-center justify-between p-2 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800 text-xs">
                  <div className="flex items-center gap-2">
                    <GitBranch className="w-3.5 h-3.5 text-indigo-500" />
                    <span className="font-semibold text-slate-700 dark:text-slate-300">git.uni.edu/cs504/lab2</span>
                  </div>
                  <ExternalLink className="w-3 h-3 text-slate-400" />
                </div>
              </div>
            </div>

            <button
              onClick={() => setShowDetailModal(assignments[1] || assignments[0])}
              className="w-full py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 font-bold text-xs transition-colors flex items-center justify-center gap-1.5"
            >
              <span>Open Workspace &amp; View Details</span>
            </button>
          </div>

          {/* Card 3: Transfer Learning */}
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col justify-between space-y-4 hover:border-indigo-300 transition-all">
            <div>
              <div className="flex items-center justify-between text-[11px] font-bold pb-2 border-b border-slate-100 dark:border-slate-800">
                <span className="text-slate-500 uppercase tracking-wider">
                  DUE NOV 16, 2024 • 9 DAYS LEFT
                </span>
                <span className="text-slate-400 font-semibold">20% Grade</span>
              </div>

              <div className="mt-3">
                <p className="text-[11px] font-extrabold uppercase tracking-wider text-indigo-600 dark:text-indigo-400">
                  CS-503 • MACHINE LEARNING
                </p>
                <h4 className="text-base font-extrabold text-slate-900 dark:text-white mt-1 leading-snug">
                  Transfer Learning on ImageNet using PyTorch
                </h4>
                <p className="text-xs text-slate-500 mt-2 line-clamp-2 leading-relaxed">
                  Fine-tune ResNet-50 vs EfficientNet-B2 architectures. Compare Top-1 accuracy, confusion matrix, and inference latencies.
                </p>
              </div>

              <div className="mt-4 p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 space-y-2">
                <div className="flex items-center justify-between text-xs font-bold">
                  <span className="text-slate-600 dark:text-slate-400">Status</span>
                  <span className="text-indigo-600 dark:text-indigo-400 font-semibold">Draft Saved (v1.2)</span>
                </div>
                <p className="text-[11px] text-slate-400 flex items-center gap-1">
                  <Clock className="w-3 h-3 text-slate-400" />
                  Notebook checkpoints uploaded 2 hours ago
                </p>
              </div>

              <div className="mt-4 space-y-1.5">
                <p className="text-[10px] uppercase font-bold text-slate-400">Course Assets</p>
                <div className="flex items-center justify-between p-2 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800 text-xs">
                  <span className="font-semibold text-slate-700 dark:text-slate-300">imagenet_subset_labels.json</span>
                  <span className="text-slate-400 text-[10px]">3.2 MB</span>
                </div>
                <div className="flex items-center justify-between p-2 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800 text-xs">
                  <span className="font-semibold text-slate-700 dark:text-slate-300">pytorch_baseline.ipynb</span>
                  <span className="text-slate-400 text-[10px]">420 KB</span>
                </div>
              </div>
            </div>

            <button
              onClick={() => {
                setSelectedAssignmentForSubmit('assign-3');
                const el = document.getElementById('quick-submit-container');
                el?.scrollIntoView({ behavior: 'smooth' });
              }}
              className="w-full py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 font-bold text-xs transition-colors"
            >
              Continue Submission
            </button>
          </div>
        </div>
      </div>

      {/* Bottom Section: Submissions History & Quick Submit Drawer */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 pt-2">
        {/* Left (2 Cols): Submissions History & Grading Table */}
        <div className="lg:col-span-2 bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-1 border-b border-slate-100 dark:border-slate-800">
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">Submissions History &amp; Grading</h3>
              <p className="text-xs text-slate-500">Graded homework solutions and TA feedback logs</p>
            </div>
            <span className="text-xs font-semibold text-slate-600 dark:text-slate-400">
              Cumulative GPA Impact: <strong className="text-indigo-600 dark:text-indigo-400 font-bold">3.84</strong>
            </span>
          </div>

          <div className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
            {submissions.map((sub) => (
              <div key={sub.id} className="py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-start gap-3">
                  <div className="w-9 h-9 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 flex items-center justify-center shrink-0">
                    <FileText className="w-4 h-4 text-indigo-500" />
                  </div>
                  <div>
                    <h5 className="font-bold text-slate-900 dark:text-white text-sm">
                      {sub.assignmentTitle}
                    </h5>
                    <div className="flex items-center gap-2 text-slate-400 text-[11px] mt-0.5">
                      <span className="font-mono font-semibold text-indigo-600 dark:text-indigo-400">
                        {sub.subjectCode}
                      </span>
                      <span>•</span>
                      <span>Submitted {sub.submittedAt}</span>
                      <span>•</span>
                      <span>{sub.fileName} ({sub.fileSize})</span>
                    </div>
                    {sub.feedback && (
                      <p className="text-[11px] text-slate-600 dark:text-slate-400 bg-slate-50 dark:bg-slate-800/60 p-2 rounded-lg mt-2 border border-slate-100 dark:border-slate-800">
                        💬 <strong>TA Feedback:</strong> {sub.feedback}
                      </p>
                    )}
                  </div>
                </div>

                <div className="flex items-center sm:flex-col sm:items-end justify-between gap-1.5 shrink-0 pl-12 sm:pl-0">
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${
                      sub.status === 'graded'
                        ? 'bg-purple-50 text-purple-700 dark:bg-purple-950/60 dark:text-purple-400 border border-purple-200 dark:border-purple-800'
                        : 'bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-400 border border-amber-200 dark:border-amber-800'
                    }`}
                  >
                    {sub.status === 'graded' ? 'Evaluated' : 'Under Review'}
                  </span>
                  {sub.score !== undefined ? (
                    <div className="flex items-center gap-1">
                      <span className="font-black text-slate-900 dark:text-white text-base">{sub.score}</span>
                      <span className="text-slate-400 text-xs">/ {sub.maxScore || 100}</span>
                      <span className="font-black text-xs px-1.5 py-0.2 rounded bg-indigo-50 dark:bg-indigo-900 text-indigo-600 dark:text-indigo-400 ml-1">
                        {sub.letterGrade}
                      </span>
                    </div>
                  ) : (
                    <span className="text-[11px] text-slate-400">Grading Queued</span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right (1 Col): Fast Lane Submit Drawer */}
        <div id="quick-submit-container">
          <QuickSubmitDrawer
            assignments={assignments}
            onSubmissionComplete={onRefreshData}
            defaultAssignmentId={selectedAssignmentForSubmit}
          />
        </div>
      </div>

      {/* Detail Modal */}
      {showDetailModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-lg w-full p-6 space-y-4 border border-slate-200 dark:border-slate-800 shadow-2xl">
            <div className="flex items-start justify-between">
              <div>
                <span className="text-[11px] font-mono font-bold text-indigo-600 dark:text-indigo-400">
                  {showDetailModal.subjectCode} • {showDetailModal.gradeWeightage}
                </span>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white mt-1">
                  {showDetailModal.title}
                </h3>
              </div>
              <button
                onClick={() => setShowDetailModal(null)}
                className="text-slate-400 hover:text-slate-600 text-xs font-bold"
              >
                Close
              </button>
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              {showDetailModal.description}
            </p>
            {showDetailModal.requirements && (
              <div className="space-y-1">
                <h5 className="text-xs font-bold text-slate-800 dark:text-slate-200">Key Deliverables:</h5>
                <ul className="list-disc list-inside text-xs text-slate-500 space-y-1">
                  {showDetailModal.requirements.map((req, i) => (
                    <li key={i}>{req}</li>
                  ))}
                </ul>
              </div>
            )}
            <div className="pt-2 flex justify-end">
              <button
                onClick={() => {
                  setSelectedAssignmentForSubmit(showDetailModal.id);
                  setShowDetailModal(null);
                  const el = document.getElementById('quick-submit-container');
                  el?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs"
              >
                Go to Quick Submit
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
