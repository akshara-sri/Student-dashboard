import React, { useState } from 'react';
import { Mail, Send, Search, User, CheckCheck, Paperclip, Clock } from 'lucide-react';
import { MessageItem, UserProfile } from '../../types';
import { dataService } from '../../services/dataService';
import { useAuth } from '../../context/AuthContext';

interface MessagesViewProps {
  messages: MessageItem[];
  onRefreshData: () => void;
}

export const MessagesView: React.FC<MessagesViewProps> = ({ messages, onRefreshData }) => {
  const { currentUser } = useAuth();
  const [activePartner, setActivePartner] = useState<{ id: string; name: string; role: any }>({
    id: 'faculty_alan_vance',
    name: 'Dr. Alan Vance',
    role: 'faculty'
  });
  const [inputText, setInputText] = useState('');
  const [sending, setSending] = useState(false);
  const [search, setSearch] = useState('');

  // Contacts
  const contacts = [
    { id: 'faculty_alan_vance', name: 'Dr. Alan Vance', role: 'Faculty • Systems', online: true },
    { id: 'faculty_sarah_jenkins', name: 'Dr. Sarah Jenkins', role: 'Faculty • Algorithms', online: false },
    { id: 'admin_dean_office', name: 'Academic Advisor Desk', role: 'Faculty Tower 4B', online: true },
  ];

  // Filter messages for active partner
  const thread = messages.filter(
    (m) => (m.senderId === activePartner.id && m.recipientId === (currentUser?.uid || 'student_elena_vance')) ||
           (m.senderId === (currentUser?.uid || 'student_elena_vance') && m.recipientId === activePartner.id)
  );

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || !currentUser) return;
    setSending(true);

    try {
      await dataService.sendMessage(
        currentUser.uid,
        currentUser.displayName,
        currentUser.role,
        activePartner.id,
        activePartner.name,
        inputText.trim()
      );
      setInputText('');
      onRefreshData();
    } catch (err) {
      console.error(err);
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="space-y-6 pb-12">
      <div>
        <span className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 flex items-center gap-1.5 mb-1">
          <span className="w-2 h-2 rounded-full bg-indigo-600" />
          Faculty &amp; Advisor Desk
        </span>
        <h1 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">
          Direct Messages &amp; Consultations
        </h1>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
          Ask questions regarding lab assignments, project submissions, and office hours
        </p>
      </div>

      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xs grid grid-cols-1 md:grid-cols-3 min-h-[580px] overflow-hidden">
        {/* Left: Contact List */}
        <div className="border-r border-slate-200 dark:border-slate-800 p-4 flex flex-col space-y-3">
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-3" />
            <input
              type="text"
              placeholder="Search faculty or advisors..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full text-xs pl-8 pr-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-1 focus:ring-indigo-500"
            />
          </div>

          <div className="space-y-1 overflow-y-auto flex-1">
            {contacts
              .filter(c => c.name.toLowerCase().includes(search.toLowerCase()))
              .map((c) => {
                const isActive = activePartner.id === c.id;
                return (
                  <button
                    key={c.id}
                    onClick={() => setActivePartner({ id: c.id, name: c.name, role: 'faculty' })}
                    className={`w-full p-3 rounded-2xl flex items-center gap-3 transition-all text-left ${
                      isActive
                        ? 'bg-indigo-50 dark:bg-indigo-950/60 border border-indigo-200 dark:border-indigo-900'
                        : 'hover:bg-slate-50 dark:hover:bg-slate-800'
                    }`}
                  >
                    <div className="relative">
                      <div className="w-10 h-10 rounded-xl bg-indigo-100 dark:bg-indigo-900 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-bold text-sm">
                        {c.name.split(' ').map(n => n[0]).join('')}
                      </div>
                      {c.online && (
                        <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 ring-2 ring-white dark:ring-slate-900 absolute -bottom-0.5 -right-0.5" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <h5 className="font-bold text-xs text-slate-900 dark:text-white truncate">{c.name}</h5>
                      <p className="text-[11px] text-slate-400 truncate">{c.role}</p>
                    </div>
                  </button>
                );
              })}
          </div>
        </div>

        {/* Right: Message Thread */}
        <div className="md:col-span-2 flex flex-col h-full bg-slate-50/40 dark:bg-slate-900/40">
          {/* Thread header */}
          <div className="p-4 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-indigo-100 dark:bg-indigo-900 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-bold text-xs">
                {activePartner.name.split(' ').map(n => n[0]).join('')}
              </div>
              <div>
                <h4 className="font-bold text-sm text-slate-900 dark:text-white">{activePartner.name}</h4>
                <p className="text-[10px] text-emerald-600 font-semibold flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" /> Online for Consultations
                </p>
              </div>
            </div>
          </div>

          {/* Messages list */}
          <div className="flex-1 p-5 overflow-y-auto space-y-4">
            {thread.length === 0 ? (
              <div className="py-20 text-center text-xs text-slate-400">
                Start a consultation with {activePartner.name}. Messages are encrypted.
              </div>
            ) : (
              thread.map((msg) => {
                const isMe = msg.senderId === (currentUser?.uid || 'student_elena_vance');
                return (
                  <div
                    key={msg.id}
                    className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
                  >
                    <div
                      className={`max-w-md p-3.5 rounded-2xl text-xs leading-relaxed shadow-2xs ${
                        isMe
                          ? 'bg-indigo-600 text-white rounded-br-xs'
                          : 'bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-700 rounded-bl-xs'
                      }`}
                    >
                      {msg.content}
                    </div>
                    <span className="text-[10px] text-slate-400 mt-1 flex items-center gap-1 px-1">
                      {msg.timestamp}
                      {isMe && <CheckCheck className="w-3 h-3 text-indigo-500" />}
                    </span>
                  </div>
                );
              })
            )}
          </div>

          {/* Input bar */}
          <form onSubmit={handleSendMessage} className="p-4 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 flex items-center gap-2">
            <button
              type="button"
              onClick={() => alert('Attachment upload opened')}
              className="w-9 h-9 rounded-xl flex items-center justify-center text-slate-400 hover:text-slate-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              <Paperclip className="w-4 h-4" />
            </button>
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder={`Message ${activePartner.name}...`}
              className="flex-1 text-xs px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:border-indigo-500"
            />
            <button
              type="submit"
              disabled={sending || !inputText.trim()}
              className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white text-xs font-bold flex items-center gap-1.5 shadow-md shadow-indigo-200 dark:shadow-none transition-colors"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Send</span>
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
