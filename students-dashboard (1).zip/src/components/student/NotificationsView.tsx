import React, { useState } from 'react';
import { Bell, CheckCheck, FileText, Calendar, AlertTriangle, Info, Check } from 'lucide-react';
import { NotificationItem } from '../../types';
import { dataService } from '../../services/dataService';

interface NotificationsViewProps {
  notifications: NotificationItem[];
  onRefreshData: () => void;
  onOpenHallTicket: () => void;
}

export const NotificationsView: React.FC<NotificationsViewProps> = ({
  notifications,
  onRefreshData,
  onOpenHallTicket
}) => {
  const [filter, setFilter] = useState<string>('all');

  const filtered = notifications.filter(n => filter === 'all' || n.category === filter);

  const handleMarkAllRead = async () => {
    await dataService.markAllNotificationsRead();
    onRefreshData();
  };

  const handleItemClick = async (notif: NotificationItem) => {
    if (!notif.read) {
      await dataService.markNotificationAsRead(notif.id);
      onRefreshData();
    }
    if (notif.actionText?.includes('Hall Ticket')) {
      onOpenHallTicket();
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 flex items-center gap-1.5 mb-1">
            <span className="w-2 h-2 rounded-full bg-indigo-600" />
            Live Bulletin &amp; Circulars
          </span>
          <h1 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">
            Notifications &amp; Alerts
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Official announcements, examination notices, and assignment updates
          </p>
        </div>

        <button
          onClick={handleMarkAllRead}
          className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-bold hover:bg-slate-50 dark:hover:bg-slate-700 flex items-center gap-1.5 shadow-2xs self-start sm:self-auto transition-colors"
        >
          <CheckCheck className="w-4 h-4 text-indigo-500" />
          <span>Mark All as Read</span>
        </button>
      </div>

      {/* Category Pills */}
      <div className="flex flex-wrap items-center gap-1.5">
        {[
          { id: 'all', label: 'All Alerts' },
          { id: 'exam', label: 'Examinations' },
          { id: 'assignment', label: 'Assignments' },
          { id: 'attendance', label: 'Attendance' },
          { id: 'announcement', label: 'Announcements' },
          { id: 'system', label: 'System' },
        ].map((cat) => (
          <button
            key={cat.id}
            onClick={() => setFilter(cat.id)}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
              filter === cat.id
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Notification Cards */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
        {filtered.length === 0 ? (
          <div className="py-16 text-center text-xs text-slate-400">
            No notifications in this category.
          </div>
        ) : (
          filtered.map((item) => {
            const isHigh = item.priority === 'high';
            return (
              <div
                key={item.id}
                onClick={() => handleItemClick(item)}
                className={`p-4 rounded-2xl border transition-all cursor-pointer flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${
                  !item.read
                    ? 'border-indigo-200 dark:border-indigo-900/60 bg-indigo-50/20 dark:bg-indigo-950/20'
                    : 'border-slate-100 dark:border-slate-800 hover:bg-slate-50/60 dark:hover:bg-slate-800/40'
                }`}
              >
                <div className="flex items-start gap-3.5">
                  <div
                    className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                      item.category === 'exam'
                        ? 'bg-purple-100 dark:bg-purple-900/60 text-purple-600 dark:text-purple-400'
                        : item.category === 'attendance'
                          ? 'bg-rose-100 dark:bg-rose-900/60 text-rose-600 dark:text-rose-400'
                          : 'bg-indigo-100 dark:bg-indigo-900/60 text-indigo-600 dark:text-indigo-400'
                    }`}
                  >
                    {item.category === 'exam' ? (
                      <Calendar className="w-4 h-4" />
                    ) : item.category === 'attendance' ? (
                      <AlertTriangle className="w-4 h-4" />
                    ) : (
                      <Bell className="w-4 h-4" />
                    )}
                  </div>

                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className={`text-xs font-bold ${!item.read ? 'text-slate-900 dark:text-white' : 'text-slate-700 dark:text-slate-300'}`}>
                        {item.title}
                      </h4>
                      {!item.read && (
                        <span className="w-2 h-2 rounded-full bg-rose-500 shrink-0" />
                      )}
                    </div>
                    <p className="text-xs text-slate-500 mt-1 leading-relaxed">{item.message}</p>
                    <span className="text-[10px] text-slate-400 mt-1.5 inline-block font-medium">
                      {item.timestamp}
                    </span>
                  </div>
                </div>

                {item.actionText && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleItemClick(item);
                    }}
                    className="px-3.5 py-1.5 rounded-xl bg-white dark:bg-slate-800 border border-indigo-200 dark:border-indigo-800 text-indigo-600 dark:text-indigo-400 text-xs font-bold shadow-2xs hover:bg-indigo-50 shrink-0 self-start sm:self-auto"
                  >
                    {item.actionText}
                  </button>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
